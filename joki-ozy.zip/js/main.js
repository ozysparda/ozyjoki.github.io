// main.js
console.log('Main JS Loaded');