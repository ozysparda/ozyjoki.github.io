// admin.js
console.log('Admin JS Loaded');