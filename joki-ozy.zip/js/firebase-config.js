// firebase-config.js
const firebaseConfig = {/* your firebase config here */};